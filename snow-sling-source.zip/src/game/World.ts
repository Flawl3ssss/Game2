import * as THREE from 'three';
import { GAME_CONFIG } from './config';
import { SeededRandom, hash32 } from './random';

export interface CoinEntity {
  active: boolean;
  collected: boolean;
  x: number;
  absZ: number;
  yOffset: number;
  slot: number;
}

export interface ObstacleEntity {
  active: boolean;
  x: number;
  absZ: number;
  radius: number;
  slot: number;
}

export interface RampEntity {
  active: boolean;
  x: number;
  absZ: number;
  width: number;
  slot: number;
}

export interface BoostEntity {
  active: boolean;
  used: boolean;
  x: number;
  absZ: number;
  width: number;
  slot: number;
}

interface TreeEntity {
  active: boolean;
  x: number;
  absZ: number;
  scale: number;
  slot: number;
}

interface Chunk {
  index: number;
  terrain: THREE.Mesh<THREE.BufferGeometry, THREE.MeshStandardMaterial>;
  terrainPosition: THREE.Vector3;
  coins: CoinEntity[];
  obstacles: ObstacleEntity[];
  ramps: RampEntity[];
  boosts: BoostEntity[];
  trees: TreeEntity[];
}

const hiddenMatrix = new THREE.Matrix4().makeScale(0, 0, 0);
const tempMatrix = new THREE.Matrix4();
const tempPosition = new THREE.Vector3();
const tempQuaternion = new THREE.Quaternion();
const tempScale = new THREE.Vector3(1, 1, 1);
const up = new THREE.Vector3(0, 1, 0);

export class InfiniteWorld {
  readonly group = new THREE.Group();
  readonly seed: number;
  originDistance = 0;
  originHeightOffset = 0;

  readonly coins: CoinEntity[] = [];
  readonly obstacles: ObstacleEntity[] = [];
  readonly ramps: RampEntity[] = [];
  readonly boosts: BoostEntity[] = [];

  private chunks: Chunk[] = [];
  private maxChunkIndex = -1;
  private coinMesh: THREE.InstancedMesh;
  private rockMesh: THREE.InstancedMesh;
  private rampMesh: THREE.InstancedMesh;
  private boostMesh: THREE.InstancedMesh;
  private trunkMesh: THREE.InstancedMesh;
  private crownMesh: THREE.InstancedMesh;
  private treeEntities: TreeEntity[] = [];
  private readonly snowMaterial: THREE.MeshStandardMaterial;

  constructor(private readonly scene: THREE.Scene, seed: number) {
    this.seed = seed;
    this.group.name = 'infinite-world';
    scene.add(this.group);

    this.snowMaterial = new THREE.MeshStandardMaterial({
      color: 0xeaf8ff,
      roughness: 0.9,
      metalness: 0,
      flatShading: true,
    });

    const chunkCount = GAME_CONFIG.activeChunks + GAME_CONFIG.chunksBehind;
    const maxCoins = chunkCount * GAME_CONFIG.maxCoinsPerChunk;
    const maxRocks = chunkCount * GAME_CONFIG.maxRocksPerChunk;
    const maxRamps = chunkCount * GAME_CONFIG.maxRampsPerChunk;
    const maxBoosts = chunkCount * GAME_CONFIG.maxBoostsPerChunk;
    const maxTrees = chunkCount * GAME_CONFIG.maxTreesPerChunk;

    this.coinMesh = new THREE.InstancedMesh(
      new THREE.TorusGeometry(0.38, 0.12, 6, 10),
      new THREE.MeshStandardMaterial({ color: 0xffd54a, emissive: 0x6b3b00, emissiveIntensity: 0.3, roughness: 0.35, metalness: 0.55 }),
      maxCoins,
    );
    this.coinMesh.castShadow = false;
    this.coinMesh.instanceMatrix.setUsage(THREE.DynamicDrawUsage);

    this.rockMesh = new THREE.InstancedMesh(
      new THREE.DodecahedronGeometry(0.95, 0),
      new THREE.MeshStandardMaterial({ color: 0x718090, roughness: 0.96, flatShading: true }),
      maxRocks,
    );
    this.rockMesh.castShadow = true;
    this.rockMesh.receiveShadow = true;
    this.rockMesh.instanceMatrix.setUsage(THREE.DynamicDrawUsage);

    this.rampMesh = new THREE.InstancedMesh(
      new THREE.BoxGeometry(4.2, 0.45, 4.8),
      new THREE.MeshStandardMaterial({ color: 0x75d1ff, roughness: 0.75, flatShading: true }),
      maxRamps,
    );
    this.rampMesh.castShadow = true;
    this.rampMesh.receiveShadow = true;
    this.rampMesh.instanceMatrix.setUsage(THREE.DynamicDrawUsage);

    this.boostMesh = new THREE.InstancedMesh(
      new THREE.BoxGeometry(3.8, 0.08, 3.4),
      new THREE.MeshStandardMaterial({ color: 0xff6fcf, emissive: 0x6f0c55, emissiveIntensity: 0.8, roughness: 0.35 }),
      maxBoosts,
    );
    this.boostMesh.instanceMatrix.setUsage(THREE.DynamicDrawUsage);

    this.trunkMesh = new THREE.InstancedMesh(
      new THREE.CylinderGeometry(0.18, 0.28, 1.8, 5),
      new THREE.MeshStandardMaterial({ color: 0x674f3a, roughness: 1, flatShading: true }),
      maxTrees,
    );
    this.crownMesh = new THREE.InstancedMesh(
      new THREE.ConeGeometry(1.15, 3.2, 7),
      new THREE.MeshStandardMaterial({ color: 0x0f6070, roughness: 0.9, flatShading: true }),
      maxTrees,
    );
    this.trunkMesh.castShadow = true;
    this.crownMesh.castShadow = true;
    this.trunkMesh.instanceMatrix.setUsage(THREE.DynamicDrawUsage);
    this.crownMesh.instanceMatrix.setUsage(THREE.DynamicDrawUsage);

    this.group.add(this.coinMesh, this.rockMesh, this.rampMesh, this.boostMesh, this.trunkMesh, this.crownMesh);

    for (let i = 0; i < maxCoins; i += 1) this.coinMesh.setMatrixAt(i, hiddenMatrix);
    for (let i = 0; i < maxRocks; i += 1) this.rockMesh.setMatrixAt(i, hiddenMatrix);
    for (let i = 0; i < maxRamps; i += 1) this.rampMesh.setMatrixAt(i, hiddenMatrix);
    for (let i = 0; i < maxBoosts; i += 1) this.boostMesh.setMatrixAt(i, hiddenMatrix);
    for (let i = 0; i < maxTrees; i += 1) {
      this.trunkMesh.setMatrixAt(i, hiddenMatrix);
      this.crownMesh.setMatrixAt(i, hiddenMatrix);
    }

    this.createChunks(chunkCount);
  }

  reset(): void {
    this.originDistance = 0;
    this.originHeightOffset = 0;
    this.maxChunkIndex = -1;
    for (let i = 0; i < this.chunks.length; i += 1) this.assignChunk(this.chunks[i], i);
    this.maxChunkIndex = this.chunks.length - 1;
    this.flushInstances();
  }

  update(playerLocalZ: number, elapsed: number): void {
    const absoluteZ = this.originDistance + playerLocalZ;
    const playerChunk = Math.floor(absoluteZ / GAME_CONFIG.chunkLength);
    const minimumChunk = Math.max(0, playerChunk - GAME_CONFIG.chunksBehind);
    const desiredMax = minimumChunk + this.chunks.length - 1;

    while (this.maxChunkIndex < desiredMax) {
      const oldest = this.chunks.reduce((a, b) => (a.index < b.index ? a : b));
      this.assignChunk(oldest, this.maxChunkIndex + 1);
      this.maxChunkIndex += 1;
    }

    for (const coin of this.coins) {
      if (!coin.active || coin.collected) continue;
      const z = coin.absZ - this.originDistance;
      const y = this.heightAtAbsolute(coin.absZ, coin.x) - this.originHeightOffset + coin.yOffset + Math.sin(elapsed * 5 + coin.slot) * 0.12;
      tempPosition.set(coin.x, y, z);
      tempQuaternion.setFromAxisAngle(up, elapsed * 2.4 + coin.slot);
      tempScale.setScalar(1);
      tempMatrix.compose(tempPosition, tempQuaternion, tempScale);
      this.coinMesh.setMatrixAt(coin.slot, tempMatrix);
    }
    this.coinMesh.instanceMatrix.needsUpdate = true;
  }

  shiftOrigin(shiftZ: number, shiftY: number): void {
    this.originDistance += shiftZ;
    this.originHeightOffset += shiftY;
    for (const chunk of this.chunks) {
      chunk.terrain.position.z -= shiftZ;
      chunk.terrain.position.y -= shiftY;
      chunk.terrainPosition.copy(chunk.terrain.position);
    }
    this.refreshAllInstanceMatrices();
  }

  floorHeight(localZ: number, x: number): number {
    return this.heightAtAbsolute(this.originDistance + localZ, x) - this.originHeightOffset;
  }

  roadHalfWidth(absoluteZ: number): number {
    return GAME_CONFIG.roadHalfWidth + Math.sin(absoluteZ * 0.005) * 1.2;
  }

  hideCoin(coin: CoinEntity): void {
    coin.collected = true;
    this.coinMesh.setMatrixAt(coin.slot, hiddenMatrix);
    this.coinMesh.instanceMatrix.needsUpdate = true;
  }

  hideBoost(boost: BoostEntity): void {
    boost.used = true;
    this.boostMesh.setMatrixAt(boost.slot, hiddenMatrix);
    this.boostMesh.instanceMatrix.needsUpdate = true;
  }

  dispose(): void {
    this.scene.remove(this.group);
    this.snowMaterial.dispose();
    for (const child of this.group.children) {
      if ('geometry' in child) (child.geometry as THREE.BufferGeometry).dispose();
      if ('material' in child) {
        const material = child.material as THREE.Material | THREE.Material[];
        if (Array.isArray(material)) material.forEach((value) => value.dispose());
        else material.dispose();
      }
    }
  }

  private createChunks(count: number): void {
    for (let i = 0; i < count; i += 1) {
      const geometry = new THREE.PlaneGeometry(
        GAME_CONFIG.terrainWidth,
        GAME_CONFIG.chunkLength,
        GAME_CONFIG.terrainSegmentsX,
        GAME_CONFIG.terrainSegmentsZ,
      );
      geometry.rotateX(-Math.PI / 2);
      const terrain = new THREE.Mesh(geometry, this.snowMaterial);
      terrain.receiveShadow = true;
      terrain.castShadow = false;
      terrain.frustumCulled = true;
      this.group.add(terrain);

      const chunk: Chunk = {
        index: -1,
        terrain,
        terrainPosition: terrain.position.clone(),
        coins: [],
        obstacles: [],
        ramps: [],
        boosts: [],
        trees: [],
      };

      const coinStart = i * GAME_CONFIG.maxCoinsPerChunk;
      for (let j = 0; j < GAME_CONFIG.maxCoinsPerChunk; j += 1) {
        const item: CoinEntity = { active: false, collected: false, x: 0, absZ: 0, yOffset: 1.25, slot: coinStart + j };
        chunk.coins.push(item);
        this.coins.push(item);
      }

      const rockStart = i * GAME_CONFIG.maxRocksPerChunk;
      for (let j = 0; j < GAME_CONFIG.maxRocksPerChunk; j += 1) {
        const item: ObstacleEntity = { active: false, x: 0, absZ: 0, radius: 1.1, slot: rockStart + j };
        chunk.obstacles.push(item);
        this.obstacles.push(item);
      }

      const rampStart = i * GAME_CONFIG.maxRampsPerChunk;
      for (let j = 0; j < GAME_CONFIG.maxRampsPerChunk; j += 1) {
        const item: RampEntity = { active: false, x: 0, absZ: 0, width: 2.5, slot: rampStart + j };
        chunk.ramps.push(item);
        this.ramps.push(item);
      }

      const boostStart = i * GAME_CONFIG.maxBoostsPerChunk;
      for (let j = 0; j < GAME_CONFIG.maxBoostsPerChunk; j += 1) {
        const item: BoostEntity = { active: false, used: false, x: 0, absZ: 0, width: 2.5, slot: boostStart + j };
        chunk.boosts.push(item);
        this.boosts.push(item);
      }

      const treeStart = i * GAME_CONFIG.maxTreesPerChunk;
      for (let j = 0; j < GAME_CONFIG.maxTreesPerChunk; j += 1) {
        const item: TreeEntity = { active: false, x: 0, absZ: 0, scale: 1, slot: treeStart + j };
        chunk.trees.push(item);
        this.treeEntities.push(item);
      }

      this.chunks.push(chunk);
    }
  }

  private assignChunk(chunk: Chunk, index: number): void {
    chunk.index = index;
    const startAbsZ = index * GAME_CONFIG.chunkLength;
    const centerLocalZ = startAbsZ - this.originDistance + GAME_CONFIG.chunkLength / 2;
    chunk.terrain.position.set(0, 0, centerLocalZ);
    chunk.terrainPosition.copy(chunk.terrain.position);
    this.updateTerrainGeometry(chunk, startAbsZ);
    this.generateChunkContent(chunk, startAbsZ);
  }

  private updateTerrainGeometry(chunk: Chunk, startAbsZ: number): void {
    const position = chunk.terrain.geometry.getAttribute('position') as THREE.BufferAttribute;
    for (let i = 0; i < position.count; i += 1) {
      const x = position.getX(i);
      const localZ = position.getZ(i) + GAME_CONFIG.chunkLength / 2;
      const absZ = startAbsZ + localZ;
      const y = this.heightAtAbsolute(absZ, x) - this.originHeightOffset;
      position.setY(i, y);
    }
    position.needsUpdate = true;
    chunk.terrain.geometry.computeVertexNormals();
    chunk.terrain.geometry.computeBoundingSphere();
  }

  private heightAtAbsolute(absZ: number, x: number): number {
    const descent = -absZ * 0.055;
    const broadWave = Math.sin(absZ * 0.016) * 0.55 + Math.sin(absZ * 0.0045 + 1.7) * 1.2;
    const narrowWave = Math.sin(absZ * 0.038 + x * 0.13) * 0.13;
    const roadHalf = this.roadHalfWidth(absZ);
    const bankDistance = Math.max(0, Math.abs(x) - roadHalf);
    const bank = bankDistance * bankDistance * 0.045;
    return descent + broadWave + narrowWave + bank;
  }

  private generateChunkContent(chunk: Chunk, startAbsZ: number): void {
    const rng = new SeededRandom(hash32(this.seed ^ chunk.index * 1013904223));
    const difficulty = Math.min(1, chunk.index / 42);

    for (const item of chunk.coins) {
      item.active = false;
      item.collected = false;
      this.coinMesh.setMatrixAt(item.slot, hiddenMatrix);
    }
    for (const item of chunk.obstacles) {
      item.active = false;
      this.rockMesh.setMatrixAt(item.slot, hiddenMatrix);
    }
    for (const item of chunk.ramps) {
      item.active = false;
      this.rampMesh.setMatrixAt(item.slot, hiddenMatrix);
    }
    for (const item of chunk.boosts) {
      item.active = false;
      item.used = false;
      this.boostMesh.setMatrixAt(item.slot, hiddenMatrix);
    }
    for (const item of chunk.trees) {
      item.active = false;
      this.trunkMesh.setMatrixAt(item.slot, hiddenMatrix);
      this.crownMesh.setMatrixAt(item.slot, hiddenMatrix);
    }

    const safeStart = chunk.index < 2 ? 18 : 5;
    const safeEnd = 6;
    const pathStyle = rng.int(0, 3);
    const coinCount = chunk.index === 0 ? 10 : rng.int(7, GAME_CONFIG.maxCoinsPerChunk);
    const lane = rng.range(-5.5, 5.5);
    for (let i = 0; i < coinCount; i += 1) {
      const item = chunk.coins[i];
      item.active = true;
      const t = coinCount <= 1 ? 0.5 : i / (coinCount - 1);
      item.absZ = startAbsZ + safeStart + t * (GAME_CONFIG.chunkLength - safeStart - safeEnd);
      if (pathStyle === 0) item.x = lane;
      else if (pathStyle === 1) item.x = Math.sin(t * Math.PI * 2) * 5.5;
      else if (pathStyle === 2) item.x = THREE.MathUtils.lerp(-6, 6, t);
      else item.x = THREE.MathUtils.lerp(6, -6, t);
      item.yOffset = 1.35 + (rng.chance(0.15) ? 0.75 : 0);
      this.setCoinMatrix(item, 0);
    }

    const obstacleCount = chunk.index < 2 ? 0 : rng.int(1, Math.max(1, Math.round(2 + difficulty * 3)));
    for (let i = 0; i < Math.min(obstacleCount, chunk.obstacles.length); i += 1) {
      const item = chunk.obstacles[i];
      item.active = true;
      item.x = rng.range(-8.2, 8.2);
      item.absZ = startAbsZ + rng.range(12, GAME_CONFIG.chunkLength - 7);
      item.radius = rng.range(0.8, 1.25);
      const y = this.heightAtAbsolute(item.absZ, item.x) - this.originHeightOffset + item.radius * 0.65;
      tempPosition.set(item.x, y, item.absZ - this.originDistance);
      tempQuaternion.setFromEuler(new THREE.Euler(rng.range(-0.35, 0.35), rng.range(0, Math.PI), rng.range(-0.2, 0.2)));
      tempScale.setScalar(item.radius);
      tempMatrix.compose(tempPosition, tempQuaternion, tempScale);
      this.rockMesh.setMatrixAt(item.slot, tempMatrix);
    }

    const rampCount = chunk.index < 1 ? 0 : (rng.chance(0.38 + difficulty * 0.12) ? 1 : 0);
    for (let i = 0; i < rampCount; i += 1) {
      const item = chunk.ramps[i];
      item.active = true;
      item.x = rng.range(-5.5, 5.5);
      item.absZ = startAbsZ + rng.range(22, GAME_CONFIG.chunkLength - 9);
      item.width = 2.5;
      const y = this.heightAtAbsolute(item.absZ, item.x) - this.originHeightOffset + 0.35;
      tempPosition.set(item.x, y, item.absZ - this.originDistance);
      tempQuaternion.setFromEuler(new THREE.Euler(-0.18, 0, 0));
      tempScale.set(1, 1, 1);
      tempMatrix.compose(tempPosition, tempQuaternion, tempScale);
      this.rampMesh.setMatrixAt(item.slot, tempMatrix);
    }

    const boostCount = chunk.index > 2 && rng.chance(0.28) ? 1 : 0;
    for (let i = 0; i < boostCount; i += 1) {
      const item = chunk.boosts[i];
      item.active = true;
      item.x = rng.range(-5.7, 5.7);
      item.absZ = startAbsZ + rng.range(14, GAME_CONFIG.chunkLength - 8);
      item.width = 2.6;
      const y = this.heightAtAbsolute(item.absZ, item.x) - this.originHeightOffset + 0.08;
      tempPosition.set(item.x, y, item.absZ - this.originDistance);
      tempQuaternion.identity();
      tempScale.set(1, 1, 1);
      tempMatrix.compose(tempPosition, tempQuaternion, tempScale);
      this.boostMesh.setMatrixAt(item.slot, tempMatrix);
    }

    const treeCount = rng.int(14, GAME_CONFIG.maxTreesPerChunk);
    for (let i = 0; i < treeCount; i += 1) {
      const item = chunk.trees[i];
      item.active = true;
      const side = rng.chance(0.5) ? -1 : 1;
      item.x = side * rng.range(12.8, GAME_CONFIG.terrainWidth / 2 - 1.4);
      item.absZ = startAbsZ + rng.range(2, GAME_CONFIG.chunkLength - 2);
      item.scale = rng.range(0.72, 1.35);
      this.setTreeMatrices(item);
    }

    this.flushInstances();
  }

  private setCoinMatrix(item: CoinEntity, elapsed: number): void {
    const y = this.heightAtAbsolute(item.absZ, item.x) - this.originHeightOffset + item.yOffset;
    tempPosition.set(item.x, y, item.absZ - this.originDistance);
    tempQuaternion.setFromAxisAngle(up, elapsed + item.slot);
    tempScale.setScalar(1);
    tempMatrix.compose(tempPosition, tempQuaternion, tempScale);
    this.coinMesh.setMatrixAt(item.slot, tempMatrix);
  }

  private setTreeMatrices(item: TreeEntity): void {
    const ground = this.heightAtAbsolute(item.absZ, item.x) - this.originHeightOffset;
    const z = item.absZ - this.originDistance;
    tempQuaternion.identity();

    tempPosition.set(item.x, ground + 0.9 * item.scale, z);
    tempScale.setScalar(item.scale);
    tempMatrix.compose(tempPosition, tempQuaternion, tempScale);
    this.trunkMesh.setMatrixAt(item.slot, tempMatrix);

    tempPosition.set(item.x, ground + 2.55 * item.scale, z);
    tempScale.setScalar(item.scale);
    tempMatrix.compose(tempPosition, tempQuaternion, tempScale);
    this.crownMesh.setMatrixAt(item.slot, tempMatrix);
  }

  private refreshAllInstanceMatrices(): void {
    for (const coin of this.coins) {
      if (coin.active && !coin.collected) this.setCoinMatrix(coin, 0);
      else this.coinMesh.setMatrixAt(coin.slot, hiddenMatrix);
    }
    for (const obstacle of this.obstacles) {
      if (!obstacle.active) {
        this.rockMesh.setMatrixAt(obstacle.slot, hiddenMatrix);
        continue;
      }
      const y = this.heightAtAbsolute(obstacle.absZ, obstacle.x) - this.originHeightOffset + obstacle.radius * 0.65;
      tempPosition.set(obstacle.x, y, obstacle.absZ - this.originDistance);
      tempQuaternion.identity();
      tempScale.setScalar(obstacle.radius);
      tempMatrix.compose(tempPosition, tempQuaternion, tempScale);
      this.rockMesh.setMatrixAt(obstacle.slot, tempMatrix);
    }
    for (const ramp of this.ramps) {
      if (!ramp.active) {
        this.rampMesh.setMatrixAt(ramp.slot, hiddenMatrix);
        continue;
      }
      const y = this.heightAtAbsolute(ramp.absZ, ramp.x) - this.originHeightOffset + 0.35;
      tempPosition.set(ramp.x, y, ramp.absZ - this.originDistance);
      tempQuaternion.setFromEuler(new THREE.Euler(-0.18, 0, 0));
      tempScale.set(1, 1, 1);
      tempMatrix.compose(tempPosition, tempQuaternion, tempScale);
      this.rampMesh.setMatrixAt(ramp.slot, tempMatrix);
    }
    for (const boost of this.boosts) {
      if (!boost.active || boost.used) {
        this.boostMesh.setMatrixAt(boost.slot, hiddenMatrix);
        continue;
      }
      const y = this.heightAtAbsolute(boost.absZ, boost.x) - this.originHeightOffset + 0.08;
      tempPosition.set(boost.x, y, boost.absZ - this.originDistance);
      tempQuaternion.identity();
      tempScale.set(1, 1, 1);
      tempMatrix.compose(tempPosition, tempQuaternion, tempScale);
      this.boostMesh.setMatrixAt(boost.slot, tempMatrix);
    }
    for (const tree of this.treeEntities) {
      if (tree.active) this.setTreeMatrices(tree);
      else {
        this.trunkMesh.setMatrixAt(tree.slot, hiddenMatrix);
        this.crownMesh.setMatrixAt(tree.slot, hiddenMatrix);
      }
    }
    this.flushInstances();
  }

  private flushInstances(): void {
    this.coinMesh.instanceMatrix.needsUpdate = true;
    this.rockMesh.instanceMatrix.needsUpdate = true;
    this.rampMesh.instanceMatrix.needsUpdate = true;
    this.boostMesh.instanceMatrix.needsUpdate = true;
    this.trunkMesh.instanceMatrix.needsUpdate = true;
    this.crownMesh.instanceMatrix.needsUpdate = true;
  }
}
